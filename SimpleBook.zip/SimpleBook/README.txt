//项目目标
    ->完成简书注册界面的测试(https://www.jianshu.com/sign_up)

//功能实现
1.对简书注册进行自动化测试
2.生成测试报告
3.生成错误日志
4.错误截图
5.邮件发送

//项目结构
1.config 配置文件和全局settings
2.tools 项目所需工具汇总 第三方模块
3.middleware 查找结点中间件
4.basepage 定位结点模块
5.handle 操作结点预设
6.readTest 操作handle输入内容
7.test 单元测试开始
report 测试报告存放位置
log 存放错误日志
screenshot 存放信息截图

//制作信息
    ->作者:陈文硕
    ->日期:2019/6/12/19:28

